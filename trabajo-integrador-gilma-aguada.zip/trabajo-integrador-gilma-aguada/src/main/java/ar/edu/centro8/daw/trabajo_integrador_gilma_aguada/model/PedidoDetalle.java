package ar.edu.centro8.daw.trabajo_integrador_gilma_aguada.model;
import jakarta.persistence.Entity;
import jakarta.persistence.Id; 
@Entity
public class PedidoDetalle {
    @Id 
    private Long idPedido;
    private Long idProducto;
    private Integer cantidad;
    private Double precioUnitario;
    // Averiguar si corresponde crear una clave primaria compuesta.Esta entidad me genera dudas

}
