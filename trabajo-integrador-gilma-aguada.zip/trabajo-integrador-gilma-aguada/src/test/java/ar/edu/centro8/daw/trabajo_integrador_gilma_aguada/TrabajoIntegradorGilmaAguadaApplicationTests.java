package ar.edu.centro8.daw.trabajo_integrador_gilma_aguada;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TrabajoIntegradorGilmaAguadaApplicationTests {

	@Test
	void contextLoads() {
	}

}
